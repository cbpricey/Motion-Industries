export default function Handled () {
    return <h1>What has been reviewed</h1>
}
export default function Footer () {
    
}